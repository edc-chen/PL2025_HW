// Copyright © 2016 Alan A. A. Donovan & Brian W. Kernighan.
// License: https://creativecommons.org/licenses/by-nc-sa/4.0/

// See page 61.
//!+

// Mandelbrot emits a PNG image of the Mandelbrot fractal.
package main

import (
	"image"
	"image/color"
	"image/png"
	"log"
	"math/cmplx"
	"os"
	"runtime"
	"sync"
	"time"
)

func main() {
	// 記錄起始時間，用來測量總執行時間
	startTime := time.Now()

	const (
		xmin, ymin, xmax, ymax = -2, -2, +2, +2
		width, height          = 1024, 1024
	)

	// 建立最終圖片
	img := image.NewRGBA(image.Rect(0, 0, width, height))

	// 使用所有可用 CPU 核心
	// 這裡使用 GOMAXPROCS(1) 是為了模擬單核心環境，實際上可以根據需要調整
	runtime.GOMAXPROCS(runtime.NumCPU())

	// 使用 WaitGroup 等待每一行的計算完成
	var wg sync.WaitGroup
	wg.Add(height)

	// 對每一行平行化：每一行都啟動一個 goroutine 處理該行所有像素
	for py := 0; py < height; py++ {
		go func(py int) {
			defer wg.Done()
			// 計算該行對應的 y 座標
			y := float64(py)/float64(height)*(ymax-ymin) + ymin
			// 逐個像素依序計算
			for px := 0; px < width; px++ {
				x := float64(px)/float64(width)*(xmax-xmin) + xmin
				z := complex(x, y)
				img.Set(px, py, mandelbrot(z))
			}
		}(py)
	}

	// 等待所有行完成後輸出結果
	wg.Wait()

	// 顯示總執行時間
	elapsed := time.Since(startTime)
	png.Encode(os.Stdout, img)
	log.Printf("總執行時間: %v\n", elapsed)

}

func mandelbrot(z complex128) color.Color {
	const iterations = 200
	const contrast = 15

	var v complex128
	for n := uint8(0); n < iterations; n++ {
		v = v*v + z
		if cmplx.Abs(v) > 2 {
			return color.Gray{255 - contrast*n}
		}
	}
	return color.Black
}

//!-

// Some other interesting functions:

func acos(z complex128) color.Color {
	v := cmplx.Acos(z)
	blue := uint8(real(v)*128) + 127
	red := uint8(imag(v)*128) + 127
	return color.YCbCr{192, blue, red}
}

func sqrt(z complex128) color.Color {
	v := cmplx.Sqrt(z)
	blue := uint8(real(v)*128) + 127
	red := uint8(imag(v)*128) + 127
	return color.YCbCr{128, blue, red}
}

// f(x) = x^4 - 1
//
// z' = z - f(z)/f'(z)
//
//	= z - (z^4 - 1) / (4 * z^3)
//	= z - (z - 1/z^3) / 4
func newton(z complex128) color.Color {
	const iterations = 37
	const contrast = 7
	for i := uint8(0); i < iterations; i++ {
		z -= (z - 1/(z*z*z)) / 4
		if cmplx.Abs(z*z*z*z-1) < 1e-6 {
			return color.Gray{255 - contrast*i}
		}
	}
	return color.Black
}
