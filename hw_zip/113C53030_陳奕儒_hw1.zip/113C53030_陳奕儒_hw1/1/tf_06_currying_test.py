import io
import unittest
import unittest.mock
import tf_06_currying as tf_06

class TestTF06(unittest.TestCase):

    def test_read_file(self):
        path_to_file = "../in.txt"
        expected = "This is a python test. This test is only a test."
        
        result = tf_06.read_file(path_to_file)
        self.assertEqual(result, expected)
    
    def test_filter_chars_and_normalize(self):
        str_data = 'This is a python test. This test is only a test.'
        expected = 'this is a python test this test is only a test '
        
        result = tf_06.filter_chars_and_normalize(str_data)
        self.assertEqual(result, expected)

    def test_scan(self):
        str_data = 'this is a python test this test is only a test '
        expected = ['this', 'is', 'a', 'python', 'test', 'this', 'test', 'is', 'only', 'a', 'test']
        
        result = tf_06.scan(str_data)
        self.assertEqual(result, expected)        

    def test_remove_stop_words(self):
        word_list = ['this', 'is', 'a', 'python', 'test', 'this', 'test', 'is', 'only', 'a', 'test']
        expected = ['python', 'test', 'test', 'test']
        file_name = '../stop_words.txt'
        
        result = tf_06.remove_stop_words(file_name)(word_list)
        self.assertEqual(result, expected)        
    
    def test_frequencies(self):
        word_list = ['python', 'test', 'test', 'test']
        expected = {'python': 1, 'test': 3}
        
        result = tf_06.frequencies(word_list)        
        self.assertEqual(result, expected)        
    
    def test_sort(self):
        word_freq = {'python': 1, 'test': 3}
        expected = [('test', 3), ('python', 1)]
        
        result = tf_06.sort(word_freq)     
        self.assertEqual(result, expected)     

    @unittest.mock.patch('sys.stdout', new_callable=io.StringIO)
    def test_print_all(self, mock_stdout):
        word_freqs = [('test', 3), ('python', 1)]
        expected = "test - 3\npython - 1\n"
        tf_06.print_all(word_freqs)
        self.assertEqual(mock_stdout.getvalue(), expected)
            


if __name__ == '__main__':
    unittest.main() 
        